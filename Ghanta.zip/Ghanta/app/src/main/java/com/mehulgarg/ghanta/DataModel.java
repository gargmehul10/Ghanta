package com.mehulgarg.ghanta;

/**
 * Created by Mehul Garg on 09-10-2017.
 */

public class DataModel {

    String time;

    public DataModel(String time) {

        this.time = time;
    }

    public String getTime() {
        return time;
    }
}
